https://www.notion.so/GPT-1d01cfa4895b802d8b44f1b219167b18?pvs=4
